var express =require('express');
var app=express();

app.set("view engine","jade")

app.get('/jaderequest',function(req,res){
   //var a=req.params.id;
    res.render('sample');
});
app.listen(3000,()=>{console.log("running....")});