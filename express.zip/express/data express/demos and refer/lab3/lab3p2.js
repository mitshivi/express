//performing all the operations on MongoDB
var express = require('express');
var app = express();
var parser =require('body-parser');
var cors = require('cors');
var fs =require('fs');
var MongoClient=require('mongodb').MongoClient;

app.use(parser.json());



//adding the data in the database
app.post('/empdata', function (req, res) {

  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  res.send(req.body);
  console.log(req.body);
  MongoClient.connect("mongodb://localhost:27017/emp",
  function(err,dbvar){
  if(err) throw err
  var col1=dbvar.db('emp');
  col1.collection('emp').insert({"empId":req.body.empId,"empName":req.body.empName,"empSalary":req.body.empSalary,"empAddress":{"city":req.body.city,"state":req.body.state}},true,function(err,res){
  if(err) throw err;
  console.log("1 document inserted");
  dbvar.close();
});
dbvar.close();
})
});

//displaying the data on the page
app.get('/empdata/show',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  MongoClient.connect("mongodb://localhost:27017/emp",
  function(err,dbvar){
  if(err) throw err
  var col1=dbvar.db('emp');
  var c=col1.collection('emp').find().toArray(function(err,result){
    if(err) throw err
    res.send(result);
    dbvar.close();
});
dbvar.close();
});
});
app.use(parser.json());

//updating the city of the employee
app.post('/empdata/cityupdate',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  MongoClient.connect("mongodb://localhost:27017/emp",function(err,dbvar){
    if(err) throw err;
    var col1=dbvar.db('emp');
    var c=col1.collection('emp').updateOne({"empName":req.body.empName},{$set:{"empAddress.city":req.body.city}},function(err){
      if (err) throw err;
      console.log("data updated");
      dbvar.close();
    });
    dbvar.close();
  });
});


//starting the server
app.use(cors()).listen(1234,()=>{
    console.log('express started');
})













