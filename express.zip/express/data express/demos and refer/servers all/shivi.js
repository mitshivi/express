const express = require('express');
const app = express();
const parser =require('body-parser');
var cors = require('cors');
var MongoClient=require('mongodb').MongoClient;

app.get('/rest/api/readbyname',(req,res)=>{
  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
 // res.json({"name":"john"});
  MongoClient.connect("mongodb://localhost:27017/emp",
  function(err,dbvar){
  if(err) throw err
  var col1=dbvar.db('emp');
  console.log("hello");
  var c=col1.collection('emp').find().toArray(function(err,result){
    if(err) throw err
    var a=result;
    //console.log(result);
    res.send(result);
    dbvar.close();
  });
  dbvar.close();
})
});

app.use(parser.json());

app.post('/ping', function (req, res) {

  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  res.send(req.body);
  //console.log(req.body);
  MongoClient.connect("mongodb://localhost:27017/emp",
  function(err,dbvar){
  if(err) throw err
  var col1=dbvar.db('emp');
  col1.collection('emp').insert(req.body,true,function(err,res){
  if(err) throw err;
  console.log("1 document inserted");
  dbvar.close();
});
dbvar.close();
})
});

app.post('/pingdel',function(req,res){
  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  res.send(req.body);
  console.log("holla"+req.body);
  MongoClient.connect("mongodb://localhost:27017/emp",
  function(err,dbvar){
  if (err) throw err
  var col1=dbvar.db('emp');
  col1.collection('emp').deleteOne(req.body,true,function(err,res){
    if(err) throw err
    console.log("Object is deleted");
    dbvar.close();
  });
  dbvar.close();
  })
});



app.use(cors()).listen(1234,()=>{
    console.log('express started');
})
