import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  constructor(private http:HttpClient) { }
  getData()
  {
  return this.http.get("http://localhost:1234/empdata/show"); 
  }

  postData(data)
  {
  console.log(data);
  return this.http.post("http://localhost:1234/empdata",{"empId":data[0],"empName":data[1],"empSalary":data[2],"city":data[3],"state":data[4]});
  }

  postCity(city,name)
  {
    console.log(city,name);
    return this.http.post("http://localhost:1234/empdata/cityupdate",{"city":city,"empName":name});
  }




}
