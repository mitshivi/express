import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  constructor(private http:HttpClient) { }

  readData()
  {
    return this.http.get("http://localhost:1234/rest/api/readbyname");
  };

  addData(data:any):Observable<any>
  {
    console.log(data);
    return this.http.post("http://localhost:1234/ping",{name:data});
  }
   
  delData(data):Observable<any>
  {
    console.log((data.name));
    return this.http.post("http://localhost:1234/pingdel",{name:data.name});
  }



  /*delData(data):Observable<any>
  {
    console.log(JSON.stringify(data));
    return this.http.delete("http://localhost:1234/ping",JSON.stringify(data));
  }*/
}
