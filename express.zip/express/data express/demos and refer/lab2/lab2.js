var app=require('http');
var fr=require('fs');
var MongoClient=require('mongodb').MongoClient;


//adding data to the product database

var x=(req,res)=>{
    MongoClient.connect("mongodb://localhost:27017/product",function(err,dbvar){
        if (err) throw err
        var col1=dbvar.db('product');
        col1.collection('products').insertOne({"Product ID":103,"Product Name":"something good","Product Cost":"456","Product Description":"beyond imagination"},function(err){
            if (err) throw err
            console.log("1 Document Inserted Successfully");
        })
    })
}
x();

