var express =require('express');
var app=express();
const pug = require('pug');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var bodyParser = require('body-parser');

app.use(cookieParser());
app.set("view engine","pug");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true })); 
app.use(session({secret: "Shh, its a secret!"}));

app.get('/', function(req, res){
   if(req.session.page_views){
      req.session.page_views++;
      res.send("You visited this page " + req.session.page_views + " times");
   } else {
      req.session.page_views = 1;
      res.send("Welcome to this page for the first time!");
   }
});

var Users = [];

app.get('/signup', function(req, res){
  
   res.render('signup');
});

app.post('/signupme', function(req, res){
   if(!req.body.id || !req.body.password){
      res.status("400");
      res.send("Invalid details!");
   } else {
      Users.filter(function(user){
         if(user.id === req.body.id){
            res.render('signup', {
               message: "User Already Exists! Login or choose another user id"});
         }
      });
      var newUser = {id: req.body.id, password: req.body.password};
      Users.push(newUser);
      req.session.user = newUser;
      //res.redirect('https://google.com');
   }
});
app.get('/shi', function(req, res){
   res.cookie('vjh',"gjgjd").send('cookie set');
   console.log('Cookies: ', req.cookies);
    //Sets name = express
});

app.get('/pugrequest',function(req,res)
{
    res.render('hello');
});

app.listen(3000,()=>{console.log("running....")});