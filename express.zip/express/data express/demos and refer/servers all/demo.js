var exp=require('express');
var app=exp();
var parser=require('parser');

app.get('/rest/api/readbyid/:id/:name',(req,res)=>{
    res.send(JSON.stringify(X));
});

app.use(parser.json());
app.post('/rest/api/readbyname',(req,res)=>{
    console.log(req.body);
});
app.listen(1234,()=>{
    console.log('express started');
});