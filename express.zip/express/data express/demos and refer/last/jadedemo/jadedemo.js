var express = require('express');
var app = express();

app.set("view engine","pug")

app.get('/jaderequest', function (req, res) {

    res.render('sample');

});

var server = app.listen(3000,()=>{
console.log('Running Engine');
});
