/*var fr=require('fs');

function f2(){
    var jsondata='{"name":"shivu","age":21}';
    var js=JSON.stringify(jsondata);
    fr.writeFileSync('data.json',jsondata);
    console.log(JSON.parse(fr.readFileSync('data.json')));
}


f2();*/



var fr=require('fs');


function display(){
    var empdata='["John","Sam","Hannah","Sarah","Rohan","Someone"]';
    var js=JSON.stringify(empdata);
    console.log(JSON.parse(js));
}
display();