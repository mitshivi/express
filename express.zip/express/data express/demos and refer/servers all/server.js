var exp=require('express');
//var parser =require('parser');
var app=exp();
//var x;
app.get('/rest/api/read/:name',(req,res)=>{
    res.send("Hello Rest "+req.params['name']);
    res.header("Access-Control-Allow-origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
});

app.post('/rest/api/readBykuch/:kuch',(req,res)=>{
    res.send("Hello Rest "+req.params['kuch']);
});

app.put('/rest/api/updateBykuch/:kuch',(req,res)=>{
    res.send("Hello Rest "+req.params['kuch']);
});
app.listen(1234,()=>{
    console.log('express started');
})



/*
C--Insert--POST
R--Select---get
U--Update---put
D--Delete---delete
*/