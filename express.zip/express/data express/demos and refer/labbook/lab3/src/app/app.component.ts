import { Component,OnInit,OnChanges } from '@angular/core';
import {EmployeeService} from './employee.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,OnChanges {
constructor(private service:EmployeeService){}

ngOnInit(){
   
   return this.service.getData().subscribe(informtion=>{this.info=informtion;console.log(this.info)});
}
ngOnChanges(){
  return this.service.getData().subscribe(informtion=>{this.info=informtion});
}

id:number;
name:string;
salary:number;
city:string;
state:string;
data:any[]=[];
info:any;
searchState:string;
stateEmp:any[]=[];
updname:string;
updcity:string;

post(){
this.data.push(this.id);
this.data.push(this.name);
this.data.push(this.salary);
this.data.push(this.city);
this.data.push(this.state);
this.service.postData(this.data).subscribe();
this.data=[];
}


get()
{
this.service.getData().subscribe(informtion=>{this.info=informtion;console.log(this.info)});
}

findemp()
{

for(let a=0;a<this.info.length;a++)
{
     if(this.info[a].empAddress.state==this.searchState)
     {
      this.stateEmp.push(this.info[a]);
     }
}


}

updateCity()
{
  this.service.postCity(this.updcity,this.updname).subscribe();
}

}
