var MongoClient=require('mongodb').MongoClient;

exports.sample=function(){

MongoClient.connect('mongodb://localhost:27017/adDatabase', function(err,db){
        if (err) throw err;
        var coll= db.db('adDatabase');
        coll.collection('ad').find({"category":"Electronics"}).toArray(function(err,data){
            if (err) throw err;
          
            console.log(data);
            //db.close();
            
        })
    })

}
exports.sa=function(){

    MongoClient.connect('mongodb://localhost:27017/adDatabase', function(err,db){
            if (err) throw err;
            var coll= db.db('adDatabase');
            coll.collection('ad').find({"category":"Electronics"}).toArray(function(err,data){
                if (err) throw err;
              
                console.log(data);
                //db.close();
                
            })
        })
    
    }
    
