var sam= require('./DAL.js')
var express= require('express')

var app=express();
app.get('/Electronics', function(req, res){
    sam.sample();
    res.end();

})
app.get('/Electronics/mobile', function(req, res){
    sam.();
    res.end();

})
app.get('/Electronics', function(req, res){
    sam.sample();
    res.end();

})






app.listen(3000,()=>{
    console.log("Server has started")
})