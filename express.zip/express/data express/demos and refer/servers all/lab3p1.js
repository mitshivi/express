//performing all the operations on the json file
var express = require('express');
var app = express();
var parser =require('body-parser');
var cors = require('cors');
const fs =require('fs');

//displaying the data in the browser
app.get('/pingdata', function (req, res) {
  res.header("Access-Control-Allow-Origin","*");
  res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
  res.send(JSON.parse(fs.readFileSync('emp.json')));
});
//adding the data in the json file
app.post('/addpingdata',function(req,res){
    res.header("Access-Control-Allow-Origin","*");
    res.header("Access-Control-Allow-Headers","Origin,X-Requested-With,Content-Type,Accept");
    req.body={"EmpId": 1008,"empName": "Jones","empSalary": 45000,"empAddress": {"city": "Delhi","state": "Delhi"}};
    fs.readFile('emp.json', 'utf-8', function(err, data) {
	if (err) throw err
	var arrayOfObjects = JSON.parse(data);
    arrayOfObjects.employees.push(req.body);
    fs.writeFileSync('emp.json',JSON.stringify(arrayOfObjects),function(err){
    if (err) throw err;
    console.log("Done");
});
});
})
//displaying employess belonging to a particular state
app.get('/pingdata/:state',function(req,res){
var state=req.params.state;
console.log(state);
fs.readFile('emp.json',function(err,data){
    if (err) throw err;
    var arrayOfObjects=JSON.parse(data);
    var arrObjects=[];
    for(i=0;i<arrayOfObjects.employees.length;i++)
    {
        if(arrayOfObjects.employees[i].empAddress.state==state)
        {
            arrObjects.push(arrayOfObjects.employees[i]);
        }
    }
    res.send(arrObjects);
})
});

//updating the city of employee
app.get('/pingdataupdate/:city/:name',function(req,res){
    var city=req.params.city;
    var name=req.params.name;
    console.log(city);
    fs.readFile('emp.json',function(err,data){
        if(err) throw err;
        var arrayOfObjects=JSON.parse(data);
        for(i=0;i<arrayOfObjects.employees.length;i++)
        {
         if(arrayOfObjects.employees[i].empName==name)
            {
                arrayOfObjects.employees[i].empAddress.city=city;
            }
        }
    (fs.writeFileSync('emp.json',JSON.stringify(arrayOfObjects)));
    res.send(JSON.parse(fs.readFileSync('emp.json')));    
    });
});


//starting the server
app.use(cors()).listen(1234,()=>{
    console.log('express started');
})
