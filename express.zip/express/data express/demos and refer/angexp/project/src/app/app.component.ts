import { Component,OnInit } from '@angular/core';
import {ProjectService} from './project.service'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
   constructor(private data:ProjectService){}
   information:any;
   userName:any;
   postData:any;
   info:any;

   ngOnInit(){
   console.log("holla");
    }


  showget(){
    console.log("hello get");
    return this.data.readData().subscribe(info=>{this.info=info
      console.log(info);
      //this.information=info;
    //  console.log(this.information['name'])
    });
    //this.userName=this.information['name'];
    //alert("Data is received");

  }

  showpost()
  {
    console.log("hello post");
    this.data.addData(this.postData).subscribe();
    alert("Data is sent");
  }

  deleteData(r){
  this.data.delData(r).subscribe();

  }
  
  
}
