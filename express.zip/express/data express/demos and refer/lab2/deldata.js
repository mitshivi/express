var app=require('http');
var fr=require('fs');
var MongoClient=require('mongodb').MongoClient;


//adding data to the product database

var displayData=(req,res)=>{
    MongoClient.connect("mongodb://localhost:27017/product",function(err,dbvar){
        if (err) throw err
        var col1=dbvar.db('product');
        col1.collection('products').deleteOne({"Product ID":101},function(err){
            if(err) throw err
            console.log("Data deleted Successfully");
        })        
    })
}
displayData();

